import app from "./app";
import { logger } from "./lib/logger";
import { startPythonBackend, proxyPythonWebSocket } from "./lib/python-backend";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const pythonBackend = startPythonBackend();
const server = app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    pythonBackend.kill();
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
proxyPythonWebSocket(server);

const shutdown = () => {
  pythonBackend.kill();
  server.close();
};
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
