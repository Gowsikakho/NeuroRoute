"""Network backend adapters."""
